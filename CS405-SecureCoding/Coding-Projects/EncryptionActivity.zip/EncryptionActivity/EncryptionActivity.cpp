#include <iostream>
#include <fstream>
#include <string>

using namespace std;

// XOR encryption function
string xor_encrypt(const string& data, const string& key) {
    string result = data;
    for (size_t i = 0; i < data.size(); ++i) {
        result[i] ^= key[i % key.size()]; // wrap around key
    }
    return result;
}

// Read text from file
string read_file(const string& filename) {
    ifstream inFile(filename);
    if (!inFile) {
        cerr << "Error opening file for reading: " << filename << endl;
        return "";
    }

    string content((istreambuf_iterator<char>(inFile)),
        istreambuf_iterator<char>());
    inFile.close();
    return content;
}

// Write text to file
void save_data_file(const string& filename, const string& data) {
    ofstream outFile(filename);
    if (!outFile) {
        cerr << "Error opening file for writing: " << filename << endl;
        return;
    }

    outFile << data;
    outFile.close();
}

int main() {
    const string key = "superkey"; // XOR encryption key
    const string inputFile = "input.txt";
    const string encryptedFile = "encrypted.txt";
    const string decryptedFile = "decrypted.txt";

    cout << "Reading input file...\n";
    string originalText = read_file(inputFile);
    cout << "Original:\n" << originalText << endl;

    cout << "\nEncrypting...\n";
    string encryptedText = xor_encrypt(originalText, key);
    save_data_file(encryptedFile, encryptedText);
    cout << "Encrypted text saved to " << encryptedFile << endl;

    cout << "\nDecrypting...\n";
    string reloadedEncrypted = read_file(encryptedFile);
    string decryptedText = xor_encrypt(reloadedEncrypted, key); // XOR again to decrypt
    save_data_file(decryptedFile, decryptedText);
    cout << "Decrypted text saved to " << decryptedFile << endl;

    cout << "\n=== Encryption Demo Complete ===" << endl;
    return 0;
}
